from flask import Flask, render_template, request
import numpy as np
from sklearn.ensemble import RandomForestRegressor

app = Flask(__name__)

# Sample dataset (replace with your actual dataset)
data = np.array([
    [0.2, 0.1, 0.3, 30, 50],   # N, P, K, moisture (%), actual_mango_count
    [0.3, 0.2, 0.2, 40, 55],
    # Add more data points
])

X = data[:, :4]  # Soil NPK and moisture values
y = data[:, 4]   # Actual mango counts

model = RandomForestRegressor(n_estimators=100)
model.fit(X, y)

@app.route('/', methods=['GET', 'POST'])
def index():
    yield_prediction = None

    if request.method == 'POST':
        nitrogen = float(request.form['nitrogen'])
        phosphorus = float(request.form['phosphorus'])
        potassium = float(request.form['potassium'])
        moisture = float(request.form['moisture'])
        
        input_values = np.array([[nitrogen, phosphorus, potassium, moisture]])
        yield_prediction = model.predict(input_values)

    return render_template('index.html', yield_prediction=yield_prediction)

if __name__ == '__main__':
    app.run(debug=True)
